/* Blinking LED34(Red) using CAN Protocol when the switch pressed on sending side(IMX6 sbc) */

#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <libdigiapix/can.h>
#include <libdigiapix/gpio.h> 				///////////////////////////////////////// GPIO library
#define MAX_RECEPTION_BUFFER	512*1024

#define DEFAULT_USER_LED_ALIAS		"34"	/////////////////////////////////////////GPIO

static can_if_t *can_if;
static struct can_filter *cfilter;
static struct can_filter *canfilter;
static bool running = true;
static bool prn_msg_info = false;
static bool prn_msg_count = false;
static gpio_value_t output_value = GPIO_LOW;
static gpio_t *gpio_output;
static int c=0;
struct gpio_interrupt_cb_data 				///////////////////////////////////////// GPIO
{
	gpio_t *gpio;
	gpio_value_t value; //Read the value of the LED GPIO
	int remaining_loops;
};

static void usage_and_exit(char *name, int exitval)
{
	printf(
		"Example application using libdigiapix CAN support\n"
		"\n"
		"Usage: %s -i <can-iface> -b <bitrate> [options]\n\n"
		"-i <can-iface>      Name of the CAN interface\n"
		"-b <bitrate>        Bitrate to use (Hz)\n"
		"-f <filters>        Comma-separated filter list in the format\n"
		"                    id:mask (id and mask values in hex)\n"
		"-p                  Print message info\n"
		"-c                  Print message counter\n"
		"-h                  Help\n"
		"\n"
		"Examples:\n"
		"%s -i can0 -b 500000 -f 023:fff,006:00f\n"
		"%s -i can1 -b 100000\n"
		"\n", name, name, name);

	exit(exitval);
}

/*
 * cleanup() - Frees all the allocated memory before exiting
 */
static void cleanup(void)
{
	if (canfilter)
		free(canfilter);

	if (can_if) 
	{
		ldx_can_stop(can_if);
		ldx_can_free(can_if);
		running = false;
	}
		/* Stop the interrupt handler thread */
	
	/* Free gpios */	
	ldx_gpio_free(gpio_output);
}

static int gpio_interrupt_cb(void *arg)
{
	struct gpio_interrupt_cb_data *data = arg;

	/* Toggle output GPIO */
	data->value = data->value ? GPIO_LOW : GPIO_HIGH; //Change LED value
	ldx_gpio_set_value(data->gpio, data->value);

	/* Decrease remaining loops */
	data->remaining_loops -= 1;

	return 0;
}
static int parse_argument(char *argv)
{
	char *endptr;
	long value;
	int n;
	errno = 0;
	value = strtol(argv, &endptr, 10);

	if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
	    || (errno != 0 && value == 0))
		return -1;

	if (endptr == argv)
	{
		n=ldx_gpio_get_kernel_number(endptr);
		return n;
	}

	return value;
}


static void sigaction_handler(int signum)
{
	/* 'atexit' executes the cleanup function */
	exit(EXIT_FAILURE);
}

/*
 * register_signals() - Registers program signals
 */
static void register_signals(void)
{
	struct sigaction action;

	action.sa_handler = sigaction_handler;
	action.sa_flags = 0;
	sigemptyset(&action.sa_mask);

	sigaction(SIGHUP, &action, NULL);
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGTERM, &action, NULL);
}

static void can_rx_callback(struct canfd_frame *frame, struct timeval *tv)
{
	static uint32_t nframe = 1;

	if (prn_msg_count) 
	{
		printf("CAN frame ---------> %u <-------------------\n", nframe);
	} 
	else 
	{
		printf("CAN frame\n");
	}

	if (prn_msg_info) 
	{
		printf(
			" - Time:        %ld.%06ld\n"
			" - Type:        %s\n"
			" - ID:          %x\n"
			" - Data length: %u\n"
			" - Data:        %02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x\n"
			"\n",
			tv->tv_sec, tv->tv_usec, ldx_can_is_extid_frame(frame) ?
			"Extended ID" : "Standard ID", ldx_can_get_id(frame), frame->len,
			frame->data[0], frame->data[1], frame->data[2], frame->data[3],
			frame->data[4], frame->data[5], frame->data[6], frame->data[7]);			
		int num=frame->data[0];
		printf("num = %d\n",num);
		printf("%d %d %d %d %d %d \n",frame->data[0],frame->data[1],frame->data[2],frame->data[3],frame->data[4],frame->data[5]); 
//		if(num==GPIO_IRQ_ERROR_NONE)
		if(num==1||num==0)
		{
			printf("dataa is receiveddddddddddddddddddddddddddd\n");

				c++;
				if(c%2==0)
					output_value=GPIO_HIGH;
			if(frame->data[0]==1)
			{
				output_value=GPIO_HIGH;
				printf("\n~~~~~~LED ON ~~~~~\n\n");
			}
			else
			{
				output_value=GPIO_LOW;
				printf("\n~~~~~~ LED OFF ~~~~~~\n\n");
			}
			ldx_gpio_set_value(gpio_output, output_value);// Set to HIGH the LED GPIO 	
			
		}
		
	}
	nframe++;
}

static int strchartimes(const char *str, int c)
{
	int count = 0;
	char *character;

	for (character = (char *)str; character && *character != '\0'; character++) 
	{
		if (*character == c)
			count++;
	}
	return count;
}

static int parse_filters(char *str, struct can_filter **cfilter, int *nfilters)
{
	int ret;
	int posible_filters;
	int good_filters = 0;
	char *p = str;

	/* First compute the number of filters */
	posible_filters = strchartimes(str, ',');
	posible_filters++;

	/* Allocate the memory for all the possible filters */
	canfilter = malloc(sizeof(struct can_filter) * posible_filters);
	if (!canfilter)
	{
		printf("Unable to allocate memory for filters\n");
		return -ENOMEM;
	}

	/* Parse the information for each filter */
	while (posible_filters-- && p)	//p is ptr of string contains all filters
	 {
		ret = sscanf(p, "%x:%x", &canfilter[good_filters].can_id, &canfilter[good_filters].can_mask);
			if (ret == 2)
			good_filters++;
	
			p = strchr(p, ',');
			if (p)
			p++;
	}

	*nfilters = good_filters;
	*cfilter = canfilter;

	return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
	struct canfd_frame frame;
	char *name = basename(argv[0]);
	char *iface;
	can_if_cfg_t ifcfg;
	int nfilters = 0;		//-->Number of valid filters found on str
	int opt;
	int ret;
	int led;
	struct can_filter deffilter;	//deffilter is struct variable
												
		/* Should match the GPIO request mode */
	struct gpio_interrupt_cb_data cb_data;	

	led = parse_argument(DEFAULT_USER_LED_ALIAS);
	gpio_output =ldx_gpio_request((unsigned int)led, GPIO_OUTPUT_LOW, REQUEST_SHARED);

	cb_data.gpio = gpio_output;
	cb_data.value = output_value;

	deffilter.can_id = 0;
	deffilter.can_mask = 0;		

	if (argc <= 3) 			
	{
		usage_and_exit(name, EXIT_FAILURE);
	}

	ldx_can_set_defconfig(&ifcfg); 	//To set default configuration

	while ((opt = getopt(argc, argv, "i:b:f:p:c")) > 0) 
	{
		switch (opt) 	
		{
			case 'i':
				iface = optarg; 	
				break;
	
			case 'b':
				ifcfg.bitrate = strtoul(optarg, NULL, 10); // int
				break;

			case 'f':
				ret = parse_filters(optarg, &cfilter, &nfilters); // int
				if (ret) 
				{
					printf("Unable to parse filter information\n\n");
					usage_and_exit(name, EXIT_FAILURE);
				}
				break;

			case 'p':
				prn_msg_info = true;  //bool
				break;

			case 'c':
				prn_msg_count = true;  //bool
				break;

			case 'h':
				usage_and_exit(name, EXIT_SUCCESS);
				break;

			default:
				usage_and_exit(name, EXIT_FAILURE);
		}
	}

	printf("Requesting CAN interface %s... ", iface); 	// can0 | can1

	can_if = ldx_can_request_by_name(iface);
	if (!can_if) 
	{
		printf("ERROR\n");
		return EXIT_FAILURE;
	}
	printf("OK\n");

	/* Register signals and exit cleanup function */
	atexit(cleanup);
	register_signals();

	/* Increase the buffer reception size */
	ifcfg.rx_buf_len = MAX_RECEPTION_BUFFER;

	printf("Initializing CAN interface... ");
	ret = ldx_can_init(can_if, &ifcfg);
	if (ret) 
	{
		printf("ERROR\n");
		goto error;
	}
	printf("OK\n");
	
	printf("******* text frame ==== %d************\n",frame.data[0]);

	if (nfilters == 0) 
	{
		nfilters = 1;
		cfilter = &deffilter;
	}
	ret = ldx_can_register_rx_handler(can_if, can_rx_callback, cfilter, nfilters);

	if (ret < 0) 
	{
		printf("Failed to register rx msg handler\n");
		goto error;
	}

	while (running) 
	{
		sleep(5);
		printf("Waiting for CAN frames...\n");
	}

error:

	printf("\n\nCan receive frame application has finished\n");

	return ret;
}
