/* configuring GPIO pin6 as Switch using CAN Protocol */

#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <libdigiapix/can.h>
/
#define TX_RETRIES	3

#define RANDOM_ID_BIT	0
#define EXT_ID_BIT	1
#define RTR_BIT		2
#define RANDOM_DLC_BIT	3

#define RANDOM_ID_MASK				0x01
#define EXT_ID_MASK				0x02
#define RTR_BIT_MASK				0x04
#define RANDOM_DLC_MASK				0x08

#define RANDOM_ID(random_id)	(random_id << RANDOM_ID_BIT)
#define EXT_ID(extended_id)	(extended_id << EXT_ID_BIT)
#define RTR(rtr)		(rtr << RTR_BIT)
#define RANDOM_DLC(dlc)		(dlc << RANDOM_DLC_BIT)

#include <libdigiapix/gpio.h>
#define DEFAULT_USER_BUTTON_ALIAS	"USER_BUTTON"

int a=1;
static gpio_t *gpio_input;

static int parse_argument(char *argv)
{
	char *endptr;
	long value;
	int n;
	errno = 0;
	value = strtol(argv, &endptr, 10);

	if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
	    || (errno != 0 && value == 0))
		return -1;

	if (endptr == argv)
	{
		n=ldx_gpio_get_kernel_number(endptr);
		return n;
	}

	return value;
}

static can_if_t *can_if;
static bool running = true;


static void usage_and_exit(char *name, int exitval)
{
	printf(
		"Example application using libdigiapix CAN support\n"
		"\n"
		"Usage: %s -i <can-iface> -b <bitrate> [options]\n\n"
		"-i <can-iface>      Name of the CAN interface\n"
		"-b <bitrate>        Bitrate to use (Hz)\n"
		"-n <num_msgs>       Number of messages to send (default 1)\n"
		"-t <delay>          Inter frame delay in ms (default 100)\n"
		"-I <msg_id>         Message id in hex (default 123)\n"
		"-l <data_length>    Payload length (default 8)\n"
		"-r                  Generate a random ID (will ignore the -I parameter)\n"
		"-p                  Generate a random payload (will ignore the -l parameter)\n"
		"-e                  Use extended id\n"
		"-R                  Set RTR\n"
		"\n"
		"Examples:\n"
		"%s -i can0 -b 500000 -n 100 -R\n"
		"%s -i can1 -b 100000\n"
		"\n", name, name, name);

	exit(exitval);
}


void ms_sleep(uint32_t ms)
{
	
	struct timespec ts;		//ts  is structure variable

	if (ms < 1000) {
		ts.tv_sec = 0;
		ts.tv_nsec = ms * 1000000;
	} else {
		ts.tv_sec = ms / 1000;
		ts.tv_nsec = (ms % 1000) * 1000000;
	}

	nanosleep(&ts, NULL);
}


static void cleanup(void)
{
	if (can_if) {
		ldx_can_stop(can_if);
		ldx_can_free(can_if);
		running = false;
	}

	ldx_gpio_stop_wait_interrupt(gpio_input);

	/* Free gpios */
	ldx_gpio_free(gpio_input);


}

static void sigaction_handler(int signum)
{
	/* 'atexit' executes the cleanup function */
	exit(EXIT_FAILURE);
}

static void register_signals(void)
{
	struct sigaction action;
	action.sa_handler = sigaction_handler;
	action.sa_flags = 0;
	sigemptyset(&action.sa_mask);

	sigaction(SIGHUP, &action, NULL);
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGTERM, &action, NULL);
}

void update_msg(struct canfd_frame *frame, uint32_t id, uint8_t dlc, uint8_t flags)
{
	
	printf("--------can send data configure--------------\n");
	int button;
	if (flags & RANDOM_ID_MASK)
		id = rand() % 2047 + 1;

	if (flags & EXT_ID_MASK) 
	{
		frame->can_id = id & CAN_EFF_MASK;
		frame->can_id |= CAN_EFF_FLAG;
	} else 
	{
		frame->can_id = id & CAN_SFF_MASK;
	}

	if (flags & RTR_BIT_MASK)
		frame->can_id |= CAN_RTR_FLAG;

	if (flags & RANDOM_DLC_MASK)
		dlc = rand() % 8 + 1;

	frame->len = dlc;
	register_signals();
	button = parse_argument(DEFAULT_USER_BUTTON_ALIAS);

	gpio_input = ldx_gpio_request((unsigned int)button, GPIO_IRQ_EDGE_RISING, REQUEST_SHARED);

	ldx_gpio_set_active_mode(gpio_input, GPIO_ACTIVE_HIGH);
//	while(1)
//	{
		printf("!!!!!!!!!!!!!!!!!!! Please press button to ON/OFF LED !!!!!!!!!!!!!!!!!!!!!\n");
		ldx_gpio_wait_interrupt(gpio_input, -1);
		
//		a=a^1;
//		if(a==0)
			printf("\n                                        ~~~~~~~~~ LED ON  ~~~~~~~\n\n");
//		else
//			printf("\n                                        ~~~~~~~~~ LED OFF ~~~~~~~~\n\n");
		frame->data[0]=0;
		frame->data[1]=1;
		frame->data[2]=2;
		frame->data[3]=3;
		frame->data[4]=4;
		frame->data[5]=5;
		frame->data[6]=6;
		frame->data[7]=7;

//	}
}

int main(int argc, char **argv)
{
	char *name = basename(argv[0]);
	char *iface;
	can_if_cfg_t ifcfg;
	int opt;
	int ret;
	uint32_t ms_delay = 1;
	uint32_t num_msgs = 1;
	uint32_t msg_id = 0x122;
	uint8_t msg_len = 8;
	uint8_t flags = 0;
	struct canfd_frame frame;

	srand (time(NULL));

	if (argc <= 3) {
		usage_and_exit(name, EXIT_FAILURE);
	}
	ldx_can_set_defconfig(&ifcfg);

	while ((opt = getopt(argc, argv, "i:b:n:t:I:l:e:r:R:p")) > 0) {
		switch (opt) {
		case 'i':

			iface = optarg;

			break;

		case 'b':
			ifcfg.bitrate = strtoul(optarg, NULL, 10);
			break;

		case 'n':
			num_msgs = strtoul(optarg, NULL, 10);
			break;

		case 't':
			ms_delay = strtoul(optarg, NULL, 10);
			break;

		case 'I':
			msg_id = strtoul(optarg, NULL, 16);
			break;

		case 'l':
			msg_len = strtoul(optarg, NULL, 10);
			break;

		case 'e':
			flags |= EXT_ID_MASK;
			break;

		case 'r':
			flags |= RANDOM_ID_MASK;
			break;

		case 'R':
			flags |= RTR_BIT_MASK;
			break;

		case 'p':
			flags |= RANDOM_DLC_MASK;
			break;

		default:
			usage_and_exit(name, EXIT_FAILURE);
		}
	}

	can_if = ldx_can_request_by_name(iface);
	if (!can_if) {
		printf("---ERROR---\n");
		return EXIT_FAILURE;
	}
	printf("----OK----\n");

	/* Register signals and exit cleanup function */
	atexit(cleanup);
	register_signals();

	printf("Initializing CAN interface... ");
	ret = ldx_can_init(can_if, &ifcfg);     // error starts from here not intializing
	if (ret) {
		printf("ERROR\n");
		goto error;
	}
	printf("OK\n");

	memset(&frame, 0, sizeof(frame));
	while (running && num_msgs) {
		int retries = TX_RETRIES;
		ms_sleep(2000);
		/* If we need to create more configuration bits, we have this variable flags*/
	
		
	update_msg(&frame, msg_id, msg_len, flags);
	
		while (retries--) {
			ret = ldx_can_tx_frame(can_if, &frame);
				perror("Data frame sent ---> ");
			if (!ret) {
				break;
			} else if (ret == -CAN_ERROR_TX_RETRY_LATER) {
				ms_sleep(1);
			} else {
				printf("Failed to send CAN frame (%d)\n", ret);
				goto error;
			}
		}

		if (!retries) {
			printf("Failed to send CAN frame after %d tries\n", ret);
			goto error;
		}

		num_msgs--;

		if (ms_delay)
		{
			ms_sleep(ms_delay);
		}
	}

	ms_sleep(1000);

error:

	printf("\n\nCan send frame application has finished\n");
	return ret;
}



 
