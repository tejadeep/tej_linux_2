#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <wiringPi.h>
#define  LedPin 1
int main(void)
{
	int s,i;
	int nbytes;
	struct sockaddr_can addr;
	struct can_frame frame;
	struct ifreq ifr;

	const char *ifname = "can0";

	if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
		perror("Error while opening socket");
		return -1;
	}

	strcpy(ifr.ifr_name, ifname);
	ioctl(s, SIOCGIFINDEX, &ifr);

	addr.can_family  = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;

	printf("%s at index %d\n can is ready to receive data\n", ifname, ifr.ifr_ifindex);

	if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Error in socket bind");
		return -2;
	}

	frame.can_id  = 0x123;


	wiringPiSetup();
	pinMode(LedPin,PWM_OUTPUT);



	printf("waiting for can\n");
	while(1)
	{
		nbytes =read(s, &frame, sizeof(struct can_frame));
		for(i=0;i<frame.can_dlc;i++)
		printf(" %d ",frame.data[i]);
		int h;


//	for(i=0;i<1024;i++)
		for(i=0;i<frame.can_dlc;i++)
		{
			switch(frame.data[i])
			{
			case 0:h=0;
				break;
			case 1:h=100;
				break;
			case 2:h=200;
				break;
			case 3:h=400;
		 		break;
			case 4:h=600;
				break;
			case 5:h=800;
	 			break;
			case 6:h=900;
	 			break;
			case 7:h=1000;
				break;
			default:printf("!!!!!!!!!!!!! No data !!!!!!!!!!!!!!\n");
				break;
			}
			pwmWrite(LedPin,h);
			delay(1000);
		}
		delay(1000);
		for(i=frame.can_dlc;i>0;i--)
		{

			switch(frame.data[i])
			{
			case 0:h=0;
				break;
			case 1:h=100;
				break;
			case 2:h=200;
				break;
			case 3:h=400;
 				break;
			case 4:h=600;
				break;
			case 5:h=800;
				break;
			case 6:h=900;
				break;
			case 7:h=1000;
				break;
			}
		pwmWrite(LedPin,h);
		delay(200);

		}

	}//end of while


	printf("\n");
	printf("Wrote %d bytes\n", nbytes);

	return 0;
}

