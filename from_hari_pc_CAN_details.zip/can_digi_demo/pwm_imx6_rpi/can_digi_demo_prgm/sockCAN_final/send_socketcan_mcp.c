#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include <linux/can.h>
#include <linux/can/raw.h>

int main(void)
{
	int s,i;
	int nbytes;
	struct sockaddr_can addr;
	struct can_frame frame;
	struct ifreq ifr;

	const char *ifname = "vcan0";

	for(i=0;i<8;i++)
		frame.data[i]=0;

	if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) 
	{
		perror("Error while opening socket");
		return -1;
	}
			// 3		29		3		1	
	printf("sockecan is %d -- pf_can %d -- sock_raw %d -- can_raw %d -----\n",s,PF_CAN,SOCK_RAW,CAN_RAW);
	strcpy(ifr.ifr_name, ifname);
	ioctl(s, SIOCGIFINDEX, &ifr);

	addr.can_family  = AF_CAN;
	printf("af_can is %d #####\n",AF_CAN);		/// AF_CAN value = 29
	addr.can_ifindex = ifr.ifr_ifindex;

	printf("%s at index %d\n", ifr.ifr_name, ifr.ifr_ifindex);// vcan0 at index 3

	if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Error in socket bind");
		return -2;
	}
					// pf= protocol family , af = address family number
	frame.can_id  = 0x154;
	frame.can_dlc=6;
	frame.data[0]='t';
	frame.data[1]='e';
	frame.data[2]='j';
	frame.data[3]='d';
	frame.data[4]='e';
	frame.data[5]='e';
	frame.data[6]='f';
		
	printf("###### canid= %x ifname %s ####\n",frame.can_id,ifname); //0x154 , vcan0

	nbytes =write (s, &frame, sizeof(struct can_frame));
	for(int i=0;i<8;i++)
		printf("%c ",frame.data[i]);
	printf("\n");	
	printf("Data sent and Wrote %d bytes\n", nbytes);

	return 0;
}

