
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <net/if.h>
#include <sys/ioctl.h>

#include <linux/can.h>
#include <linux/can/raw.h>

#include "lib.h"

int main(int argc, char **argv)
{
	printf("*************** 111111111 ************\n");
	int s; /* can raw socket */ 
	int nbytes;
	struct sockaddr_can addr;
	struct can_frame frame;
	struct ifreq ifr;

	int i;
		
	/* CAN message to be sent out */
	unsigned char buff[] = "123#DEADABCD";// 7DF is  msg_ID & remaining is data

	fprintf(stderr,"CAN testing\n");
	
	/* parse CAN frame */
	if (parse_canframe(buff, &frame)){
	printf("*************** 22222 on error ************\n");
		fprintf(stderr, "\nWrong CAN-frame format!\n\n");
		fprintf(stderr, "Try: <can_id>#{R|data}\n");
		fprintf(stderr, "can_id can have 3 (SFF) or 8 (EFF) hex chars\n");
		fprintf(stderr, "data has 0 to 8 hex-values that can (optionally)");
		fprintf(stderr, " be seperated by '.'\n\n");
		fprintf(stderr, "e.g. 5A1#11.2233.44556677.88 / 123#DEADBEEF / ");
		fprintf(stderr, "5AA# /\n     1F334455#1122334455667788 / 123#R ");
		fprintf(stderr, "for remote transmission request.\n\n");
		return 1;
	}

	/* open socket */
	if ((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
	printf("*************** 3333333333 on error ************\n");
		perror("socket");
		return 1;
	}

	addr.can_family = AF_CAN;

	strcpy(ifr.ifr_name, "can0");
	if (ioctl(s, SIOCGIFINDEX, &ifr) < 0) {
	printf("*************** 444444444 on error ************\n");
		perror("SIOCGIFINDEX");
		return 1;
	}
	addr.can_ifindex = ifr.ifr_ifindex;

	
	setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, NULL, 0);

	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
	printf("*************** 555555555 on error ************\n");
		perror("bind");
		return 1;
	}

	/* send frame */
	for(i=0;i<100;i++)
	{
	//    uint32_t timer02=8timer01+;
		if ((nbytes = write(s, &frame, sizeof(frame))) != sizeof(frame))
	       	{

			perror("write");
			return 1;
		}
		
		fprintf(stderr, "%d \n", i);

		usleep(10000); /* Delay before next loop */
	}

	printf("***************  8888888 ************\n");
	close(s);
	return 0;
}
