/*
 * Copyright 2018, Digi International Inc.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <libdigiapix/can.h>

#define TX_RETRIES	2

#define RANDOM_ID_BIT	0
#define EXT_ID_BIT	1
#define RTR_BIT		2
#define RANDOM_DLC_BIT	3

#define RANDOM_ID_MASK				0x01
#define EXT_ID_MASK				0x02
#define RTR_BIT_MASK				0x04
#define RANDOM_DLC_MASK				0x08

#define RANDOM_ID(random_id)	(random_id << RANDOM_ID_BIT)
#define EXT_ID(extended_id)	(extended_id << EXT_ID_BIT)
#define RTR(rtr)		(rtr << RTR_BIT)
#define RANDOM_DLC(dlc)		(dlc << RANDOM_DLC_BIT)

//////////////////////////////////////////////////////////////////   LED libraries  ////////////////////////////////////////////////


#include <libdigiapix/gpio.h>
#define DEFAULT_USER_BUTTON_ALIAS	"USER_BUTTON"
#define TEST_LOOPS			20
int a=1;
static gpio_t *gpio_input;

/*struct gpio_interrupt_cb_data {
	gpio_t *gpio;
	gpio_value_t value;
	int remaining_loops;
};*/


static int parse_argument(char *argv)
{
	char *endptr;
	long value;
	int n;
	errno = 0;
	value = strtol(argv, &endptr, 10);

	if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
	    || (errno != 0 && value == 0))
		return -1;

	if (endptr == argv)
	{
		n=ldx_gpio_get_kernel_number(endptr);
		printf("n va ##########lue %d \n",n); //37
		return n;
	}

	return value;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
static can_if_t *can_if;
static bool running = true;

/*
 * usage_and_exit() - Show usage information and exit with 'exitval' return
 *		      value
 *
 * @name:	Application name.
 * @exitval:	The exit code.
 */

//char *p="ktejadee";



static void usage_and_exit(char *name, int exitval)
{
	printf(
		"Example application using libdigiapix CAN support\n"
		"\n"
		"Usage: %s -i <can-iface> -b <bitrate> [options]\n\n"
		"-i <can-iface>      Name of the CAN interface\n"
		"-b <bitrate>        Bitrate to use (Hz)\n"
		"-n <num_msgs>       Number of messages to send (default 1)\n"
		"-t <delay>          Inter frame delay in ms (default 100)\n"
		"-I <msg_id>         Message id in hex (default 123)\n"
		"-l <data_length>    Payload length (default 8)\n"
		"-r                  Generate a random ID (will ignore the -I parameter)\n"
		"-p                  Generate a random payload (will ignore the -l parameter)\n"
		"-e                  Use extended id\n"
		"-R                  Set RTR\n"
		"\n"
		"Examples:\n"
		"%s -i can0 -b 500000 -n 100 -R\n"
		"%s -i can1 -b 100000\n"
		"\n", name, name, name);

	exit(exitval);
}

/*
 * ms_sleep() - Wait ms miliseconds
 *
 * ms:		Number of ms to wait.
 */
void ms_sleep(uint32_t ms)
{
	printf("---------------entrered into sleeping mode--------------\n");
	struct timespec ts;		//ts  is structure variable

	if (ms < 1000) {
		ts.tv_sec = 0;
		ts.tv_nsec = ms * 1000000;
	} else {
		ts.tv_sec = ms / 1000;
		ts.tv_nsec = (ms % 1000) * 1000000;
	}

	nanosleep(&ts, NULL);
}

/*
 * cleanup() - Frees all the allocated memory before exiting
 */
static void cleanup(void)
{
	printf("entered into cleanup process-----------------\n");
	if (can_if) {
		ldx_can_stop(can_if);
		ldx_can_free(can_if);
		running = false;
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////
	ldx_gpio_stop_wait_interrupt(gpio_input);

	/* Free gpios */
	ldx_gpio_free(gpio_input);

///////////////////////////////////////////////////////////////////////////////////////////////////////////
}

/*
 * sigaction_handler() - Handler to execute after receiving a signal
 *
 * @signum:	Received signal.
 */
static void sigaction_handler(int signum)
{
	/* 'atexit' executes the cleanup function */
	printf("--------------entered into sigaction-----------------\n");
	exit(EXIT_FAILURE);
}

/*
 * register_signals() - Registers program signals
 */
static void register_signals(void)
{
	struct sigaction action;
	printf("-----------------enter into register signal-------------\n");

	action.sa_handler = sigaction_handler;
	action.sa_flags = 0;
	sigemptyset(&action.sa_mask);

	sigaction(SIGHUP, &action, NULL);
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGTERM, &action, NULL);
}

void update_msg(struct canfd_frame *frame, uint32_t id, uint8_t dlc, uint8_t flags)
{
	
	printf("--------can send data configure--------------\n");
	uint8_t index;
	int button;
	if (flags & RANDOM_ID_MASK)
		id = rand() % 2047 + 1;

	if (flags & EXT_ID_MASK) 
	{
		frame->can_id = id & CAN_EFF_MASK;
		frame->can_id |= CAN_EFF_FLAG;
	} else 
	{
		frame->can_id = id & CAN_SFF_MASK;
	}

	if (flags & RTR_BIT_MASK)
		frame->can_id |= CAN_RTR_FLAG;

	if (flags & RANDOM_DLC_MASK)
		dlc = rand() % 8 + 1;

	frame->len = dlc;
/////////////////////////////////////////////////////////////////////////////////////////	
	printf("press the buttonnnnnnnnn\n");
	register_signals();
	button = parse_argument(DEFAULT_USER_BUTTON_ALIAS);
	printf("butttttttttttton in  %d \n",button); ////37

	gpio_input = ldx_gpio_request((unsigned int)button, GPIO_IRQ_EDGE_RISING, REQUEST_SHARED);
	printf("@#^&^******************* %d *(&&&&&&&&&&&&&&&^^^^^^^\n",gpio_input);

	
	

	ldx_gpio_set_active_mode(gpio_input, GPIO_ACTIVE_HIGH);

	//for (i = 0; i < TEST_LOOPS; i++) {
	//	printf("enter into a loop77777\n");
	//	for(int j=0;j<1000;j++);


		
		printf("!!!!!!!!!!!!!!!!!!! Please press button rey idiott !!!!!!!!!!!!!!!!!!!!!\n");
		int num=ldx_gpio_wait_interrupt(gpio_input, -1);
		printf("&&&&&&&&&&&&^^^^^^ handler====%d !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",num);
		
	/*	if (ldx_gpio_start_wait_interrupt(gpio_input, &gpio_interrupt_cb, &cb_data)!= EXIT_SUCCESS) 
		{
		printf("Failed to start interrupt handler thread\n");
		return EXIT_FAILURE;
		}
	*/	
		a=a^1;
		frame->data[0]=num;
		frame->data[1]=a;
printf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa=======================%d...........\n",frame->data[1]);
		/*if (ldx_gpio_wait_interrupt(gpio_input, -1) == GPIO_IRQ_ERROR_NONE) {
			printf("enter in Ifffffff condition");
			printf("Press %d; toggling output GPIO\n", i + 1);
			output_value = output_value ? GPIO_LOW : GPIO_HIGH;
			ldx_gpio_set_value(gpio_output, output_value);

		}
		else
		{
			printf("not entered into ifffffff condition");

		}*/


	
//////////////////////////////////////////////////////////////////////////////////////////////
	/* Currently we just do incremental updates on the payload */
	

/*
		for (index = 1; index < dlc; index++) {
		frame->data[index] = p[index];
		if (frame->data[index])
			break;
	}*/

}

int main(int argc, char **argv)
{
	printf("1::----------can_sending data started-------------\n");
	char *name = basename(argv[0]);
	char *iface;
	can_if_cfg_t ifcfg;
	int opt;
	int ret;
	uint32_t ms_delay = 1;
	uint32_t num_msgs = 1;
	uint32_t msg_id = 0x123;
	uint8_t msg_len = 8;
	uint8_t flags = 0;
	struct canfd_frame frame;

	srand (time(NULL));

	if (argc <= 3) {
	printf("2::-----------------------\n");
		usage_and_exit(name, EXIT_FAILURE);
	}
	printf("5::-----------------------\n");
//printf("2::----------------------%d !!!!!!!!!!!!!!!! %d \n",ifcfg,&ifcfg);
	ldx_can_set_defconfig(&ifcfg);

	while ((opt = getopt(argc, argv, "i:b:n:t:I:l:e:r:R:p")) > 0) {
	printf("3::-----------------------\n");
	printf("4::************** %s ************ \n",optarg); // it will prints getopt command line arguments
		switch (opt) {
		case 'i':

			iface = optarg;

			break;

		case 'b':
			ifcfg.bitrate = strtoul(optarg, NULL, 10);
			break;

		case 'n':
			num_msgs = strtoul(optarg, NULL, 10);
			break;

		case 't':
			ms_delay = strtoul(optarg, NULL, 10);
			break;

		case 'I':
			msg_id = strtoul(optarg, NULL, 16);
			break;

		case 'l':
			msg_len = strtoul(optarg, NULL, 10);
			break;

		case 'e':
			flags |= EXT_ID_MASK;
			break;

		case 'r':
			flags |= RANDOM_ID_MASK;
			break;

		case 'R':
			flags |= RTR_BIT_MASK;
			break;

		case 'p':
			flags |= RANDOM_DLC_MASK;
			break;

		default:
			usage_and_exit(name, EXIT_FAILURE);
		}
	}

	printf("Requesting CAN interface %s... ", iface); //iface == can0

	can_if = ldx_can_request_by_name(iface);
	printf("&&&&&&&&&&& name of can %s****  **** \n",can_if);  //can_if == can0
	if (!can_if) {
		printf("---ERROR---\n");
		return EXIT_FAILURE;
	}
	printf("----OK----\n");

	/* Register signals and exit cleanup function */
	atexit(cleanup);
	register_signals();

	printf("Initializing CAN interface... ");
	printf("4::-----------------------\n");
	ret = ldx_can_init(can_if, &ifcfg);     // error starts from here not intializing
	printf(" error in init ret value is %d &&&&&&&& \n",ret);
	if (ret) {
		printf("ERROR\n");
		goto error;
	}
	printf("OK\n");

	memset(&frame, 0, sizeof(frame));
printf("-----------------before while can send-----------------------\n");
	while (running && num_msgs) {
		int retries = TX_RETRIES;
		ms_sleep(2000);
		/* If we need to create more configuration bits, we have this variable flags*/
		update_msg(&frame, msg_id, msg_len, flags);

		while (retries--) {
				printf("8::+++++++++++++++++++++ trsn+++++++++++++\n");
			ret = ldx_can_tx_frame(can_if, &frame);
				printf("9::+++++++++++++++++++++ %d +++++++++++++\n",ret);
				perror("error is ----------");
			if (!ret) {
				printf("&&&&&&&&&  break &&&&&&&&&\n");
				break;
			} else if (ret == -CAN_ERROR_TX_RETRY_LATER) {
				printf("&&&&&&&&&&&&&& value is 25 &&&&&&&&&&&&\n");
				ms_sleep(1);
			} else {
				printf("Failed to send CAN frame (%d)\n", ret);
				goto error;
			}
		}

		if (!retries) {
			printf("Failed to send CAN frame after %d tries\n", ret);
			goto error;
		}

		num_msgs--;

		if (ms_delay)
		{
			printf("&&&&&&&&&&&&&&&& entered into ms-delay &&&&&&&&&&&\n");		
			ms_sleep(ms_delay);
		}
	}
	printf("10:::++++++++++++++++++++++++++before sleep+++++++++++++++++++++++++\n");

	ms_sleep(1000);

error:

	printf("\n\nCan send frame application has finished\n");
	printf("6::-----------------------\n");
	return ret;
}




